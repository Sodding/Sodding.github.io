var checkExist = setInterval(function() {
   if (document.getElementById('launcher'));
      console.log("Exists!");
      var div = document.getElementById('launcher');
      div.remove();
      clearInterval(checkExist);
}, 1000);