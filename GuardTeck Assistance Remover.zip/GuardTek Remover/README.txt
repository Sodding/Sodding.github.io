Pour ajouter cette extension

1 - Aller dans "Gérer les extensions"

2 - Cocher la case en bas a droite "Mode Développeur"

3 - Faire une extraction du zip

4 - Glisser le document dans le navigateur

5 - Recharger la page GuardTek